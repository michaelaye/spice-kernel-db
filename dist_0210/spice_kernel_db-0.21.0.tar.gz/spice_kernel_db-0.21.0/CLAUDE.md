# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Install in development mode
pip install -e ".[dev]"

# Run full test suite
pytest tests/

# Run a single test class or test
pytest tests/test_kernel_db.py::TestResolveKernel
pytest tests/test_kernel_db.py::TestResolveKernel::test_exact_match_preferred_mission

# Preview documentation locally
cd docs && quarto preview
```

There is no linter or formatter configured. CI runs pytest across Python 3.11–3.14; the publish workflow deploys Quarto docs to GitHub Pages (chained after CI passes).

## Architecture

Content-addressed SPICE kernel database. Every kernel file is identified by its SHA-256 hash, not its filename. Multiple filesystem locations (across missions) can reference the same hash, enabling deduplication and cross-mission reuse.

### DuckDB Schema (6 tables)

- **`kernels`** — unique file content: `(sha256 PK, filename, kernel_type, size_bytes)`
- **`locations`** — where files live on disk: `(sha256 + abs_path PK, mission, source_url, scanned_at)` → references `kernels`
- **`metakernel_entries`** — kernel entries within a `.tm` file: `(mk_path + entry_index PK, raw_entry, filename)`
- **`metakernel_registry`** — tracked metakernel files: `(mk_path PK, mission, source_url, filename, acquired_at)`
- **`missions`** — configured missions: `(name PK, server_url, mk_dir_url, dedup, added_at)`
- **`kernel_coverage`** — cached SPK body coverage intervals: `(sha256 + body_id PK, et_start, et_end, source)`

### Module Responsibilities

| Module | Role |
|--------|------|
| `db.py` | `KernelDB` class — all DB operations, scanning, resolution, metakernel rewriting, get, browse |
| `parser.py` | `ParsedMetakernel` dataclass; parse/write `.tm` files; symbol resolution |
| `hashing.py` | `sha256_file()`, `classify_kernel()` (extension→type), `guess_mission()` (path heuristic) |
| `remote.py` | Network operations: fetch metakernels, resolve URLs, parallel HEAD/download with rich.progress |
| `config.py` | `Config` dataclass, TOML persistence at `~/.config/spice-kernel-db/config.toml` |
| `cli.py` | argparse CLI with interactive mission setup, metakernel selection, and dispatching to `KernelDB` |

### Key Design Decisions

**Mission-aware resolution** (`resolve_kernel`) uses a 3-step fallback:
1. Exact filename in preferred mission
2. Exact filename in any mission
3. Path-suffix match (file exists on disk under a different canonical name)

Each fallback step emits a warning. Fuzzy prefix matching was removed in v0.10.0 due to silent data corruption risk.

Steps 1 and 2 go through `find_by_filename`, which joins on `sha256`, so identical content under two names produces one `kernels` row and a `locations` row per name — and either name matches both. `_prefer_exact_name` puts the location actually named `filename` first, so a name always resolves to its own file; the differently-named copy is used only when nothing of that name is registered, with a warning (issue #9).

**Metakernel rewriting** only modifies `PATH_VALUES` — the header, `PATH_SYMBOLS`, `KERNELS_TO_LOAD`, and all comments are preserved verbatim. A symlink tree bridges between where the metakernel expects files and where they actually live.

**Remote browsing** parses Apache `mod_autoindex` HTML directory listings. Version tags like `_v461_20251127_001` are stripped to group versioned snapshots under their base metakernel name.

**Case-insensitive fuzzy matching** — all mission name lookups (get, browse, metakernels, mission remove) use case-insensitive prefix matching. `get_mission()` resolves via the `missions` table; SQL queries on `metakernel_registry` use `LOWER(mission) LIKE LOWER(?) || '%'` directly.

**Output formatting** uses `rich` throughout — `rich.Table` and `rich.Panel` for all tabular output, `rich.progress.Progress` for download and query progress bars (thread-safe with `ThreadPoolExecutor`).

## Development rules

**Docs ship with the feature, not after.** Every new CLI subcommand, every new flag on an existing subcommand, every new public method on `KernelDB`, and every new behavior visible to the user (new error class, new exit code, new output format) must land in the same change as the corresponding documentation update. Concretely:

- New or changed CLI subcommand → entry in `docs/cli.qmd` (table of options + at least one example).
- New CLI flag → row added to the relevant subcommand's options table in `docs/cli.qmd`.
- New `KernelDB` method or `__init__.py` export → entry in `docs/api.qmd`.
- New user-visible error or recovery path → entry in `docs/troubleshooting.qmd`.
- New feature → `CHANGELOG.md` entry under the unreleased section (or current dev version).

A pull request that adds features without updating docs is incomplete. If you spot an existing gap while doing other work, fix it in the same PR rather than filing a TODO.

## Testing Patterns

Tests use `pytest-tmp-files` for temporary directory fixtures. The main fixture `tmp_spice_tree` creates a realistic multi-mission SPICE directory tree with known duplicates. Network operations are mocked with `unittest.mock.patch`. Metakernel content is written as multi-line strings in tests.

## Release Process

**IMPORTANT: Always update the changelog when bumping the version. Never commit a version bump without a corresponding changelog entry.**

1. Commit all changes with descriptive messages
2. Update version in `pyproject.toml` (minor for features, patch for fixes)
3. Add entry to `CHANGELOG.md` (Keep a Changelog format) with comparison link at bottom
4. Commit as "Bump version to X.Y.Z: brief description"
5. Push to GitHub: `git push`
6. Publish to PyPI: `rm -rf dist/ && python -m build && python -m twine upload dist/*`
7. Create GitHub release: `gh release create vX.Y.Z --title "vX.Y.Z" --notes "..."`
8. Build conda package from the in-repo recipe: `conda-build conda/ --output-folder /tmp/conda-output --no-anaconda-upload` (bump `version`, `sha256` and any new run deps in `conda/meta.yaml` first; `grayskull pypi spice-kernel-db` regenerates a recipe from scratch if the in-repo one ever drifts)
9. Upload to anaconda.org: `anaconda --site anaconda upload /tmp/conda-output/noarch/spice-kernel-db-X.Y.Z-py_0.conda`

**Notes:**
- The `--site anaconda` flag is required for `anaconda` commands (bypasses an interactive prompt that fails in non-TTY environments)
- `grayskull`, `conda-build` and `anaconda-client` live in the conda `base` env (`/Users/maye/miniforge3/bin/`), not in `py314` — conda-build's docs require base, and a `conda` inside a work env breaks VS Code's environment discovery for it
- The conda recipe maintainer in `meta.yaml` should be `michaelaye` (grayskull defaults to a placeholder)
