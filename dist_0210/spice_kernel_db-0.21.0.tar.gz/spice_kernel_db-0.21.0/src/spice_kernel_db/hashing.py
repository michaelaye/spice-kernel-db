"""File hashing and kernel classification utilities."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path


def sha256_file(path: str | Path, chunk_size: int = 1 << 20) -> str:
    """Compute SHA-256 hex digest of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(chunk_size):
            h.update(chunk)
    return h.hexdigest()


# Extension -> SPICE kernel type
KERNEL_TYPES: dict[str, str] = {
    ".bc": "ck",
    ".bsp": "spk",
    ".bpc": "pck",
    ".tpc": "pck",
    ".tf": "fk",
    ".ti": "ik",
    ".tls": "lsk",
    ".tsc": "sclk",
    ".bds": "dsk",
    ".tm": "mk",
}

# All extensions we consider kernel files
KERNEL_EXTENSIONS: set[str] = set(KERNEL_TYPES.keys())


def classify_kernel(filename: str) -> str:
    """Return the SPICE kernel type from the file extension."""
    _, ext = os.path.splitext(filename.lower())
    return KERNEL_TYPES.get(ext, "unknown")


# Known mission identifiers for path-based guessing
_KNOWN_MISSIONS = (
    "juice", "mro", "mex", "vex", "rosetta", "cassini", "juno",
    "messenger", "dawn", "maven", "insight", "odyssey", "lro",
    "clipper", "bepi", "exomars", "europa", "envision", "hera",
    "lucy", "psyche", "osiris-rex", "new-horizons", "ladee",
)

_GENERIC_PREFIXES = (
    "de4", "de3", "jup", "sat", "mar", "ura", "nep", "plu",
    "naif", "pck", "earth", "gm_",
)


def canonicalize_mission(name: str | None) -> str:
    """Normalise a mission name to its canonical form (H4).

    All mission storage and comparison goes through this — without it,
    ``JUICE``/``juice``/``Juice`` ended up as separate ``missions`` rows
    on case-sensitive filesystems and as colliding directories on
    case-insensitive ones. We pick uppercase as canonical with two
    exceptions: ``generic`` and ``unknown`` stay lowercase because the
    rest of the code (notably ``guess_mission``) treats them as
    sentinels for "no specific mission."
    """
    if not name:
        return "unknown"
    s = name.strip()
    if s.lower() in ("generic", "unknown"):
        return s.lower()
    return s.upper()


def guess_mission(filepath: str) -> str:
    """Best-effort mission name from path components.

    Heuristic: look for a directory named before 'kernels/' that isn't
    a generic infrastructure name, then fall back to kernel-type directory
    patterns, then to filename patterns. Result is run through
    :func:`canonicalize_mission` for consistent casing.
    """
    _KERNEL_TYPE_DIRS = {"ck", "spk", "pck", "fk", "ik", "lsk", "sclk", "dsk", "mk"}
    parts = Path(filepath).parts
    # Pattern: .../MISSION/kernels/...
    for i, p in enumerate(parts):
        if p.lower() == "kernels" and i > 0:
            candidate = parts[i - 1]
            if candidate.lower() not in ("naif", "pub", "data", "spice"):
                return canonicalize_mission(candidate)

    # Pattern: .../MISSION/<kernel_type>/file (no intermediate kernels/ dir)
    for i, p in enumerate(parts):
        if p.lower() in _KERNEL_TYPE_DIRS and i > 0:
            candidate = parts[i - 1]
            if candidate.lower() not in (
                "naif", "pub", "data", "spice", "kernels",
            ) and "generic" not in candidate.lower():
                return canonicalize_mission(candidate)

    # Fallback: known mission names in filename
    name = Path(filepath).stem.lower()
    for mission in _KNOWN_MISSIONS:
        if mission in name:
            return canonicalize_mission(mission)

    if name.startswith(_GENERIC_PREFIXES):
        return "generic"

    return "unknown"
